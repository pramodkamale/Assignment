// server.ts
import express from 'express';
import mongoose, { ConnectOptions } from 'mongoose'; // Import the ConnectOptions type from mongoose
import cors from 'cors';

const app = express();
const PORT = 5000;
const MONGODB_URI = 'mongodb://localhost:27017/chartdata'; // Replace with your MongoDB URI

app.use(cors());
app.use(express.json());

mongoose.connect(MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  } as ConnectOptions); // Use 'as ConnectOptions' to satisfy the typings
  

mongoose.connection.on('connected', () => {
  console.log('Connected to MongoDB');
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
