// src/App.tsx
import React, { useEffect, useState } from 'react';
import { Line } from 'react-chartjs-2';

interface DataPoint {
  value: number;
  timestamp: string;
}

const App: React.FC = () => {
  const [data, setData] = useState<DataPoint[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch('http://localhost:5000/api/data');
      const jsonData = await response.json();
      setData(jsonData);
    };
    fetchData();
  }, []);

  const chartData = {
    labels: data.map((point) => point.timestamp),
    datasets: [
      {
        label: 'Value',
        data: data.map((point) => point.value),
        fill: false,
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1,
      },
    ],
  };

  return (
    <div className="App">
      <h1>Live Data Updates on Charts</h1>
      <div style={{ width: '80%', margin: 'auto' }}>
        <Line data={chartData} />
      </div>
    </div>
  );
};

export default App;
