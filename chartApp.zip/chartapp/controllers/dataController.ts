// controllers/dataController.ts
import { Request, Response } from 'express';
import DataPointModel, { DataPoint } from '../models/dataPoint';

export const getData = async (req: Request, res: Response) => {
  try {
    const dataPoints: DataPoint[] = await DataPointModel.find().sort('-timestamp').limit(50);
    res.json(dataPoints);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching data' });
  }
};
