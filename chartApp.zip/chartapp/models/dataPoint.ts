// models/dataPoint.ts
import mongoose from 'mongoose';

export interface DataPoint {
  value: number;
  timestamp: Date;
}

const dataPointSchema = new mongoose.Schema<DataPoint>({
  value: { type: Number, required: true },
  timestamp: { type: Date, required: true, default: Date.now },
});

const DataPointModel = mongoose.model<DataPoint>('DataPoint', dataPointSchema);

export default DataPointModel;
